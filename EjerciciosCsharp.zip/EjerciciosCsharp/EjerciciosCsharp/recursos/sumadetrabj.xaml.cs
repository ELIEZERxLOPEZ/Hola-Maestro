﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para sumadetrabj.xaml
    /// </summary>
    public partial class sumadetrabj : Window
    {
        public sumadetrabj()
        {
            InitializeComponent();
        }

        private void HorasTraboPreviewTextInput(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            if (string.IsNullOrWhiteSpace(trabajadores.Text) ||
                string.IsNullOrWhiteSpace(Horas.Text) ||
                string.IsNullOrWhiteSpace(TarifaTxt.Text)) {
                MessageBox.Show("Por favor, completa todos los campos con valores numéricos mayores a 0.");
                return;
            } else {
            double x, salario, horastrabajadas, tarifa, suma, numerotrabajadores;
            suma = 0;
            
            numerotrabajadores = double.Parse(trabajadores.Text);
            tarifa = double.Parse(TarifaTxt.Text);
            horastrabajadas = double.Parse(Horas.Text);
            for (x = 1; x <= numerotrabajadores; x = x + 1) {
             
                salario = horastrabajadas * tarifa;
                suma = suma + salario;
            }
           Results.Text = "la suma de los salarios es: " + suma;
        }
            }
                
    }
}
