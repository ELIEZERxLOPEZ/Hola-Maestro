﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para Media.xaml
    /// </summary>
    public partial class Media : Window
    {
        public Media()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            // Obtiene el TextBox que disparó el evento.
            TextBox textBox = sender as TextBox;

            // Permite el signo negativo solo al principio del texto y si no hay otro '-'
            if (e.Text == "-" && !textBox.Text.Contains("-") && textBox.CaretIndex == 0) {
                e.Handled = false; // Permite el '-'
            }
            // Permite solo la entrada de dígitos y un punto decimal.
            else if (char.IsDigit(e.Text, 0)) {
                e.Handled = false; // Permite dígitos
            } else if (e.Text == "." && !textBox.Text.Contains(".")) {
                e.Handled = false; // Permite un solo punto decimal
            } else {
                e.Handled = true; // Bloquea cualquier otra entrada
            }
        }

        /// <summary>
        /// Manejador de eventos para el clic del botón "Calcular".
        /// Calcula la media de un número ingresado 100 veces y muestra el resultado.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double suma = 0;
            double numero;
            double media;

            // Intenta parsear el número del TextBox 'nusmero'.
            // Asegúrate de que en tu XAML tengas un TextBox con x:Name="nusmero".
            if (!double.TryParse(nusmero.Text, out numero)) {
                MessageBox.Show("Por favor, introduce un número válido en el campo de entrada.", "Error de Entrada", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Suma el número 100 veces.
            for (int x = 1; x <= 100; x++) {
                suma = suma + numero;
            }

            // Calcula la media y la redondea a 2 decimales.
            media = Math.Round(suma / 100, 2);

            // Muestra el resultado en el TextBox 'Equivalencia1'.
            // Asegúrate de que en tu XAML tengas un TextBox con x:Name="Equivalencia1".
            Equivalencia1.Text = $"{media}";
        }
    }
}
