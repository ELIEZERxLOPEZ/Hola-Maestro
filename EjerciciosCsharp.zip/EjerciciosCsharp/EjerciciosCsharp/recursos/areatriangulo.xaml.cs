﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para areatriangulo.xaml
    /// </summary>
    public partial class areatriangulo : Window
    {
        public areatriangulo()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double ladoa, ladob, ladoc, sm, areatriangulo;
            
            ladoa = double.Parse(Coeficiente1.Text);
            
            ladob = double.Parse(Coeficiente2.Text);
            
            ladoc = double.Parse(Coeficiente3.Text);
            sm = (ladoa + ladob + ladoc) / 2;
            areatriangulo = Math.Round(Math.Pow(sm * (sm - ladoa) * sm * (sm - ladob) * sm
            * (sm - ladoc), 0.5), 2);
            area.Text = $"{areatriangulo}";
        }
    }
}
