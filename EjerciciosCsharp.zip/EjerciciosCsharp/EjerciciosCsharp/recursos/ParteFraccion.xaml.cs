﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Globalization;


namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para ParteFraccion.xaml
    /// </summary>
    public partial class ParteFraccion : Window
    {
        public ParteFraccion()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            TextBox textBox = sender as TextBox;

            // Simula cómo quedaría el texto si se agrega el nuevo carácter
            string nuevoTexto = textBox.Text.Insert(textBox.SelectionStart, e.Text);

            // Solo permite números decimales positivos válidos (una coma o punto como decimal)
            e.Handled = !double.TryParse(nuevoTexto, out _);
        }
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double numero, pf;
           
            numero = double.Parse(nusmero.Text, CultureInfo.InvariantCulture);

            pf = Math.Truncate(numero);
            if (numero == pf) {
                Equivalencia1.Text = "no tiene parte fraccionaria";
            } else {
                Equivalencia1.Text = "tiene parte fraccionaria";
            }
        }
    }
}
