﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para Sumadedigitos.xaml
    /// </summary>
    public partial class Sumadedigitos : Window
    {
        public Sumadedigitos()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            int numero, suma, residuo;
            suma = 0;
            
            numero = int.Parse(numbers.Text);
            do {
                residuo = numero % 10;
                suma = suma + residuo;
                numero = (numero - (numero % 10)) / 10;
            }
            while (numero != 0);
            {

                Equivalencia1.Text = "" + suma;
            }

        }
    }
}
