﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para Lectorvocal.xaml
    /// </summary>
    public partial class Lectorvocal : Window
    {
        public Lectorvocal()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Verifica si un carácter dado es una vocal (a, e, i, o, u), sin importar mayúsculas o minúsculas.
        /// </summary>
        /// <param name="c">El carácter a verificar.</param>
        /// <returns>True si el carácter es una vocal, de lo contrario, False.</returns>
        private bool IsVowel(char c) {
            char lowerChar = char.ToLower(c);
            return lowerChar == 'a' || lowerChar == 'e' || lowerChar == 'i' || lowerChar == 'o' || lowerChar == 'u';
        }

        /// <summary>
        /// Agrega el texto ingresado, desglosado por caracteres, al TextBox de la lista.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void agrgegarbtn_Click(object sender, RoutedEventArgs e) {
            // Verifica que el campo de calificación no esté vacío.
            if (!string.IsNullOrWhiteSpace(calificaciontxt.Text)) {
                // Limpia el TextBox de la lista antes de agregar nuevos caracteres.
                listatxt.Clear();

                // Desglosa el texto en caracteres y los añade al listatxt con un salto de línea.
                foreach (char c in calificaciontxt.Text) {
                    listatxt.Text += c.ToString() + "\n";
                }
                // Limpia el campo de calificación después de agregar.
                calificaciontxt.Clear();
            } else {
                // Muestra un mensaje si el campo está vacío.
                MessageBox.Show("Por favor, introduce texto en el campo de calificación.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        /// <summary>
        /// Manejador de eventos para el clic del botón "Calcular".
        /// Busca la última vocal en el texto de la lista y la muestra.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            // Limpia el TextBox de resultado antes de un nuevo cálculo.
            Results.Clear();

            string listContent = listatxt.Text;
            char lastVowel = '\0'; // Inicializa con un carácter nulo

            // Itera sobre el contenido de la lista de atrás hacia adelante para encontrar la última vocal.
            for (int i = listContent.Length - 1; i >= 0; i--) {
                char currentChar = listContent[i];
                if (IsVowel(currentChar)) {
                    lastVowel = currentChar;
                    break; // Una vez encontrada la última vocal, se sale del bucle.
                }
            }

            // Muestra el resultado.
            if (lastVowel != '\0') {
                Results.Text = lastVowel.ToString();
            } else {
                Results.Text = "No se encontraron vocales.";
            }
        }
    
}
}
