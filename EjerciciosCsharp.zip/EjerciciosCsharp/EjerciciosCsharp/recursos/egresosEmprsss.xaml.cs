﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos {
    /// <summary>
    /// Lógica de interacción para egresosEmprsss.xaml
    /// </summary>
    public partial class egresosEmprsss : Window {
        public egresosEmprsss() {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double caja, egreso, cont, totalegresos, restocaja;
            totalegresos = 0;
            caja = 371;
            cont = 0;
            do {
                cont = cont + 1;
                Console.Write("Ingrese {0} egreso: ", cont);
                egreso = double.Parse(egrresed.Text);
                totalegresos = totalegresos + egreso;
                restocaja = caja - totalegresos;
            }
            while (egreso != -1);
            {

                egrrs1.Text = $"El total de egresos es: {totalegresos + 1}";
                sonbram.Text = $"Lo sobrante en caja es: {restocaja - 1}"
                 ;

            }
        }
    }
}
