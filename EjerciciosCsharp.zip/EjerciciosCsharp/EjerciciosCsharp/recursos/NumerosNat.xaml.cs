﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para NumerosNat.xaml
    /// </summary>
    public partial class NumerosNat : Window
    {
        public NumerosNat()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            Results1.Clear();
            int x, numero, suma;
            Console.Write("ingrese el numero N :  ");
            numero = int.Parse(NumN.Text);
            suma = 0;
            for (x = 1; x <= numero; x = x + 1) {
                suma = suma + x;
                Results1.Text += "n"+ x + ": " + x + "\n";
            }
            
            Output.Text = "La suma de la serie es: " + suma;
        }
    }
}
