﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para MinutosAdias.xaml
    /// </summary>
    public partial class MinutosAdias : Window
    {
        public MinutosAdias()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            int tiempo, dias, horas, minutos, x;
            Console.WriteLine("ingrese un tiempo en minutos");
            tiempo = int.Parse(tiempominutes.Text);
            if (tiempo >= 0) {
                dias = (tiempo - (tiempo % 60)) / 1440;
                x = tiempo % 1440;
                horas = (x - (x % 60)) / 60;
                minutos = x % 60;
                Days.Text = "" + dias;
                Hours.Text = "" + horas;
                Mins.Text = "" + minutos;
            } else {
                MessageBox.Show("el tiempo no puede ser negativo");
            }
           
        }
    }
}
