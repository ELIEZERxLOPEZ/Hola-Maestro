﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos {
    /// <summary>
    /// Lógica de interacción para restaurtante.xaml
    /// </summary>
    public partial class restaurtante : Window {
        public restaurtante() {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double consumo, descuento, total, c;
            c = 1;
            total = 0;
            do {


                c = c + 1;
                Console.Write("Ingrese {0}º consumo:  ", c - 1);
                consumo = double.Parse(nusmero.Text);
                if (consumo > 130) {
                    descuento = consumo * 0.15;
                } else {
                    descuento = 0;
                }
                consumo = consumo - descuento;
                total = total + consumo; 
                
            } while (c <= 130);
            Equivalencia1.Text = ""+ total;
        } 
    }
}

            
    

