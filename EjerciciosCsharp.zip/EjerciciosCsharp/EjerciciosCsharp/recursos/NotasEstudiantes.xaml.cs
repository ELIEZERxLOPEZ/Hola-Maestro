﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos {
    /// <summary>
    /// Lógica de interacción para NotasEstudiantes.xaml
    /// </summary>
    public partial class NotasEstudiantes : Window {
        public NotasEstudiantes() {
            InitializeComponent();
        }

        /// <summary>
        /// Valida que solo se ingresen números en el campo de texto.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento de composición de texto.</param>
        private void nonegative(object sender, TextCompositionEventArgs e) {
            // Permite solo la entrada de números.
            e.Handled = !int.TryParse(e.Text, out _);
        }

        /// <summary>
        /// Agrega la calificación ingresada al área de texto de la lista.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void agrgegarbtn_Click(object sender, RoutedEventArgs e) {
            // Verifica que el campo de calificación no esté vacío.
            if (!string.IsNullOrWhiteSpace(calificaciontxt.Text)) {
                // Agrega la calificación al listatxt, seguida de una nueva línea.
                listatxt.Text += calificaciontxt.Text + "\n";
                // Limpia el campo de calificación después de agregar.
                calificaciontxt.Clear();
            } else {
                // Muestra un mensaje si el campo está vacío.
                MessageBox.Show("Por favor, introduce una calificación.", "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        /// <summary>
        /// Calcula las estadísticas de las notas ingresadas (aprobadas, desaprobadas, promedios).
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            // Lista para almacenar las notas.
            List<double> notas = new List<double>();

            // Divide el texto del listatxt en líneas y parsea cada nota.
            string[] lineasNotas = listatxt.Text.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string linea in lineasNotas) {
                if (double.TryParse(linea, out double nota)) {
                    // Asegura que las notas estén en un rango razonable antes de agregarlas.
                    // Aquí se asume un rango de 0 a 20 como en el código original.
                    if (nota >= 0 && nota <= 100) {
                        notas.Add(nota);
                    } else {
                        MessageBox.Show($"La nota '{linea}' está fuera del rango válido (0-20) y será ignorada.", "Advertencia de Nota", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                } else {
                    MessageBox.Show($"No se pudo leer la nota '{linea}'. Asegúrate de que todas las entradas sean números válidos.", "Error de Formato", MessageBoxButton.OK, MessageBoxImage.Error);
                    // Si hay un error de parseo, es mejor detener el cálculo o limpiar la lista para evitar errores.
                    return; // Detiene la ejecución si hay una nota inválida.
                }
            }

            // Si no hay notas, muestra un mensaje y sale.
            if (notas.Count == 0) {
                MessageBox.Show("No hay notas para calcular. Por favor, agrega algunas notas.", "Sin Notas", MessageBoxButton.OK, MessageBoxImage.Information);
                // Limpia los campos de resultados.
                EquivalenciaAp.Text = "";
                EquivalenciaAp2.Text = "";
                EquivalenciaRep.Text = "";
                EquivalenciaRep2.Text = "";
                Results.Text = "";
                return;
            }

            // Inicialización de contadores y acumuladores.
            double cantidadAprobadas = 0;
            double cantidadDesaprobadas = 0;
            double acumuladasAprobadas = 0;
            double acumuladasDesaprobadas = 0;
            double acumuladasTotales = 0;

            // Itera sobre las notas para clasificarlas y acumularlas.
            foreach (double nota in notas) {
                if (nota >= 0 && nota <= 69) // Notas desaprobadas 
                {
                    cantidadDesaprobadas++;
                    acumuladasDesaprobadas += nota;
                } else if (nota > 69 && nota <= 100) // Notas aprobadas 
                  {
                    cantidadAprobadas++;
                    acumuladasAprobadas += nota;
                }
                acumuladasTotales += nota;
            }

            // Cálculo de promedios.
            double promedioAprobadas = 0;
            if (cantidadAprobadas > 0) {
                promedioAprobadas = Math.Round(acumuladasAprobadas / cantidadAprobadas, 1);
            }

            double promedioDesaprobadas = 0;
            if (cantidadDesaprobadas > 0) {
                promedioDesaprobadas = Math.Round(acumuladasDesaprobadas / cantidadDesaprobadas, 1);
            }

            double promedioFinal = Math.Round(acumuladasTotales / notas.Count, 1);

            // Muestra los resultados en los TextBoxes correspondientes.
            // a) Cuantas notas tiene desaprobados.
            EquivalenciaRep.Text = cantidadDesaprobadas.ToString();
            // b) Cuantos aprobados.
            EquivalenciaAp.Text = cantidadAprobadas.ToString();
            // c) El promedio de notas.
            // Para este, se asume que 'Results' mostrará el promedio final junto con otros detalles.
            // d) El promedio de notas aprobadas y desaprobadas.
            EquivalenciaAp2.Text = promedioAprobadas.ToString();
            EquivalenciaRep2.Text = promedioDesaprobadas.ToString();


            // Construye el texto de resultados finales.
            StringBuilder sbResultados = new StringBuilder();
            
            sbResultados.AppendLine($"{promedioFinal}");

            Results.Text = sbResultados.ToString();
        }
    }
}