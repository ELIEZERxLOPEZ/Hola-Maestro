﻿using System;
using System.Collections.Generic; // Añadido para compatibilidad con el código original si fuera necesario
using System.Linq; // Añadido para compatibilidad con el código original si fuera necesario
using System.Text;
using System.Threading.Tasks; // Añadido para compatibilidad con el código original si fuera necesario
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data; // Añadido para compatibilidad con el código original si fuera necesario
using System.Windows.Documents; // Añadido para compatibilidad con el código original si fuera necesario
using System.Windows.Input; // Añadido para compatibilidad con el código original
using System.Windows.Media; // Añadido para compatibilidad con el código original
using System.Windows.Media.Imaging; // Añadido para compatibilidad con el código original
using System.Windows.Shapes; // Añadido para compatibilidad con el código original

namespace EjerciciosCsharp.recursos {
    /// <summary>
    /// Lógica de interacción para EmisionFactura.xaml
    /// </summary>
    public partial class EmisionFactura : Window {
        public EmisionFactura() {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        /// <summary>
        /// Muestra los detalles de una factura en el TextBox 'data'.
        /// </summary>
        /// <param name="precioventa">El precio de venta del producto/servicio.</param>
        /// <param name="iva">El porcentaje o valor del impuesto sobre el valor añadido (IVA).</param>
        /// <param name="preciobruto">El precio bruto antes de descuentos.</param>
        /// <param name="descuento">El monto del descuento aplicado.</param>
        /// <param name="totalpagar">El total final a pagar después de impuestos y descuentos.</param>
        public void DisplayInvoiceInTextBox(double precioventa, double iva, double preciobruto, double descuento, double totalpagar) {
            // Se asume que el TextBox en el XAML se llama 'data'.
            if (data != null) {
                StringBuilder invoiceText = new StringBuilder();

                invoiceText.AppendLine("Datos de la factura");
                invoiceText.AppendLine(""); // Línea en blanco para espaciado
                invoiceText.AppendLine($"Precio de venta: {precioventa:C2}"); // :C2 para formato de moneda (ej. $150.00)
                invoiceText.AppendLine($"Impuesto sobre el valor añadido (IVA) es: {iva:P2}"); // :P2 para formato de porcentaje (ej. 18.00%)
                invoiceText.AppendLine($"Precio bruto es: {preciobruto:C2}");
                invoiceText.AppendLine($"Descuento es: {descuento:C2}");
                invoiceText.AppendLine($"Total a pagar: {totalpagar:C2}");

                data.Text = invoiceText.ToString();
            } else {
                // Muestra un mensaje de error si el TextBox 'data' no se encuentra en el XAML.
                MessageBox.Show("Error: El TextBox 'data' no fue encontrado en el XAML.", "Error de UI", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Manejador de eventos para el clic del botón de cálculo de factura.
        /// Calcula los valores de la factura y los muestra en el TextBox 'data'.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double precio, numeroarticulos, precioventa, descuento, preciobruto, iva, totalpagar;

            // Intenta parsear el precio. Si falla, muestra un error y sale.
            if (!double.TryParse(pricetxt.Text, out precio)) {
                MessageBox.Show("Por favor, introduce un precio válido en el campo 'Precio'.", "Error de Entrada", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Intenta parsear el número de artículos. Si falla, muestra un error y sale.
            if (!double.TryParse(numarticulostxt.Text, out numeroarticulos)) {
                MessageBox.Show("Por favor, introduce un número de artículos válido en el campo 'Número de Artículos'.", "Error de Entrada", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            precioventa = precio * numeroarticulos;
            iva = Math.Round(precioventa * 0.15, 2); // Asumiendo un IVA del 15%
            preciobruto = precioventa + iva;

            if (preciobruto >= 50) {
                descuento = Math.Round((preciobruto * 5) / 100, 2); // 5% de descuento si el precio bruto es >= 50
            } else {
                descuento = 0; // No hay descuento
            }
            totalpagar = preciobruto - descuento;

            // Llama a la función para mostrar la factura en el TextBox 'data'.
            DisplayInvoiceInTextBox(precioventa, iva, preciobruto, descuento, totalpagar);
        }

        private void HorasTraboPreviewTextInput(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }
    }
}
