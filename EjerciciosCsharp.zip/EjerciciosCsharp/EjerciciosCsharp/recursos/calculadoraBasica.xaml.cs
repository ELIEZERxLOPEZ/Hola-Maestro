﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para calculadoraBasica.xaml
    /// </summary>
    public partial class calculadoraBasica : Window
    {
        public calculadoraBasica()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double num1, num2, c, suma, resta, multiplicacion, division;
            c = 0;
           
                c = c + 1;
                
                num1 = double.Parse(val1.Text);
                
                num2 = double.Parse(val2.Text);
                suma = num1 + num2;
                resta = num1 - num2;
                multiplicacion = num1 * num2;
                division = Math.Round(num1 / num2, 2);
           

                sumatxt.Text = $"{suma}";
                restatxt.Text = $"{resta}";
                Multitxt.Text = $"{multiplicacion}";

            if (num1 == 0 || num2 == 0) {
                divstxt.Text = "Operacion invalida";
            } else {
                divstxt.Text = $"{division}";
            }
        }
    }
}
