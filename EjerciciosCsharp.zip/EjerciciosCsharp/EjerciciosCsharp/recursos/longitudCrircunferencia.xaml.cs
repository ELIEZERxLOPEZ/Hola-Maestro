﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para longitudCrircunferencia.xaml
    /// </summary>
    public partial class longitudCrircunferencia : Window
    {
        public longitudCrircunferencia()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double pi, radio, area, volumen, longitud;
            pi = 3.14;
            radio = int.Parse(ratio.Text);
            longitud = 2 * pi * radio;
            area = Math.Round(pi * Math.Pow(radio, 2), 2);
            volumen = Math.Round((4 / 3) * pi * Math.Pow(radio, 3), 2);
           
             longi.Text = ""+ longitud;
            ar.Text = ""+area;
             volu.Text = ""+volumen;
        }
    }
}
