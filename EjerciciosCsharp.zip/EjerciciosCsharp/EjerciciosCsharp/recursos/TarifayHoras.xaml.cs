﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para TarifayHoras.xaml
    /// </summary>
    public partial class TarifayHoras : Window
    {
        public TarifayHoras()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double horastrabajadas, tarifa, salario;
           
            horastrabajadas = double.Parse(horasTr.Text);
            
            tarifa = double.Parse(Tarifatxt.Text);
            salario = horastrabajadas * tarifa;
            Equivalencia.Text = "RD$ " + salario;
        }
    }
}
