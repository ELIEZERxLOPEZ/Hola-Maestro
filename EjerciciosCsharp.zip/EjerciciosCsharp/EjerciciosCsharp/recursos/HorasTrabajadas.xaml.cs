﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para HorasTrabajadas.xaml
    /// </summary>
    public partial class HorasTrabajadas : Window
    {
        public HorasTrabajadas()
        {
            InitializeComponent();
        }

        private void HorasTraboPreviewTextInput(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double tarifa, horastrabajadas, horasextra, salario, tarifaextra;
       
            horastrabajadas = double.Parse(___HorasTrabo_.Text);
            
            tarifa = double.Parse(___Tarifa_.Text);
            if (horastrabajadas <= 40 && horastrabajadas >= 0) {
                salario = horastrabajadas * tarifa;
                Results.Text = "el salario es: " + salario;
            } else if (horastrabajadas > 40) {
                horasextra = horastrabajadas - 40;
                tarifaextra = tarifa + 0.5 * tarifa;
                salario = horasextra * tarifaextra + 40 * tarifa;
                Results.Text = "el salario es: " + salario;
            } else
                Results.Text = "las horas trabajadas no pueden ser negativas";
        }
        }
    }

