﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para RaizcuadradaCubica.xaml
    /// </summary>
    public partial class RaizcuadradaCubica : Window
    {
        public RaizcuadradaCubica()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double numero, c, cubo, raizcuadrada; ;
            c = 0;
         
                c = c + 1;
                Console.WriteLine("PROCESO Nº{0}:", c);
                Console.Write("ingrese un numero:  ");
                numero = double.Parse(numess.Text);
                if (numero != 0) {
                }
                cubo = Math.Pow(numero, 3);
                raizcuadrada = Math.Round(Math.Pow(numero, 0.5), 2);
                cubo2.Text =  $"{cubo}";
                cubo1.Text = $"{numero}";
                cuadrado1.Text = $"{numero}";
                cuadrado2.Text = $"{raizcuadrada}";

                }
    }
}
