﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input; // Necesario para TextCompositionEventArgs

namespace EjerciciosCsharp.recursos {
    /// <summary>
    /// Lógica de interacción para parimpar.xaml
    /// </summary>
    public partial class parimpar : Window {
        public parimpar() {
            InitializeComponent();
        }

        /// <summary>
        /// Valida que solo se ingresen números (enteros) en el campo de texto.
        /// Permite el signo negativo al inicio para números negativos.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento de composición de texto.</param>
        private void nonegative(object sender, TextCompositionEventArgs e) {
            // Obtiene el TextBox que disparó el evento.
            TextBox textBox = sender as TextBox;

            // Permite el signo negativo solo al principio del texto y si no hay otro '-'
            if (e.Text == "-" && !textBox.Text.Contains("-") && textBox.CaretIndex == 0) {
                e.Handled = false; // Permite el '-'
            } else {
                // Permite solo la entrada de dígitos.
                e.Handled = !int.TryParse(e.Text, out _);
            }
        }

        /// <summary>
        /// Manejador de eventos para el clic del botón "Calcular".
        /// Clasifica los números dentro de un rango dado en pares/impares y positivos/negativos/cero,
        /// y muestra los resultados en los TextBoxes correspondientes.
        /// </summary>
        /// <param name="sender">El objeto que disparó el evento.</param>
        /// <param name="e">Argumentos del evento enrutado.</param>
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            // Limpia los resultados anteriores al iniciar un nuevo cálculo.
            parestxt.Text = "";
            imparestxt.Text = "";
            positivostxt.Text = "";
            negativostxt.Text = "";

            int startNum, endNum;

            // Intenta parsear el número de inicio del rango.
            // Asegúrate de que los nombres de los TextBox en tu XAML sean 'startNumTxt' y 'endNumTxt'.
            if (!int.TryParse(numMin.Text, out startNum)) {
                MessageBox.Show("Por favor, introduce un número inicial válido.", "Error de Entrada", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Intenta parsear el número final del rango.
            if (!int.TryParse(NumMax.Text, out endNum)) {
                MessageBox.Show("Por favor, introduce un número final válido.", "Error de Entrada", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Asegura que el número inicial no sea mayor que el número final.
            if (startNum > endNum) {
                MessageBox.Show("El número inicial no puede ser mayor que el número final.", "Error de Rango", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Inicializa los contadores.
            int pares = 0;
            int impares = 0;
            int positivos = 0;
            int negativos = 0;

            // Itera sobre el rango de números para clasificarlos.
            for (int numero = startNum; numero <= endNum; numero++) {
                // Determina si es par o impar.
                if (numero % 2 == 0) {
                    pares++;
                } else {
                    impares++;
                }

                // Determina si es positivo, negativo o cero.
                if (numero > 0) {
                    positivos++;
                } else if (numero < 0) {
                    negativos++;
                }
                // Si numero es 0, no se cuenta como positivo ni negativo en estas categorías.
            }

            // Muestra los resultados en los TextBoxes correspondientes.
            // Asegúrate de que los nombres de los TextBox en tu XAML sean 'paresOutputTxt',
            // 'imparesOutputTxt', 'positivosOutputTxt', 'negativosOutputTxt'.
            parestxt.Text = pares.ToString();
            imparestxt.Text = impares.ToString();
            positivostxt.Text = positivos.ToString();
            negativostxt.Text = negativos.ToString();
        }
    }
}
