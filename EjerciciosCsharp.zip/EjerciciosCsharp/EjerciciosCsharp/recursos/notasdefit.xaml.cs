﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para notasdefit.xaml
    /// </summary>
    public partial class notasdefit : Window
    {
        public notasdefit()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            // Permite solo la entrada de números.
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double nota1, nota2, promedio;
            Console.Write("ingrese primera nota: ");
            nota1 = double.Parse(calificaciontxt.Text);
            Console.Write("ingrese seunda nota: ");
            nota2 = double.Parse(calificaciontxt_Copiar.Text);
            promedio = (nota1 + nota2) / 2;
            if (nota1 >= 0 && nota1 <= 20 && nota2 >= 0 && nota2 <= 20) {
                if (promedio >= 10.5 && promedio <= 20) {
                  
                    promedios.Text = ""+promedio;
                    EquivalenciaAp.Text = "aprobado";
                } else {

                    promedios.Text = "" + promedio;
                    EquivalenciaAp.Text = "reprobado";
                }
            } else {
                
                EquivalenciaAp.Text = "EROR... Las notas ingresadas no se encuentran en la escala vigesimal(0 - 20)";
              }
            
        }
    }
}
