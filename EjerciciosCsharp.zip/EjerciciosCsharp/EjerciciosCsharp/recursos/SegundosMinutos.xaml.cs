﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para SegundosMinutos.xaml
    /// </summary>
    public partial class SegundosMinutos : Window
    {
        public SegundosMinutos()
        {
            InitializeComponent();
        }


        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }
        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            int tiemposegundos, minutos, segundosrestantes;
            Console.WriteLine("ingrese el tiempo en segundos");
            tiemposegundos = int.Parse(tiemposeconds.Text);
            if (tiemposegundos < 60 && tiemposegundos > 0) {
                segundosrestantes = 60 - tiemposegundos;
                Equivalencia1.Text = "Le falta " + segundosrestantes + " segundos para convertirse en minuto";
                Equivalencia1.FontSize = 12;
                Equivalencia2.Text = " ";
            } else if (tiemposegundos >= 60) {
                minutos = (tiemposegundos - (tiemposegundos % 60)) / 60;
                segundosrestantes = tiemposegundos % 60;
                Equivalencia1.Text = minutos + " minutos";
                Equivalencia2.Text = " Faltan " + segundosrestantes + " segundos para convertirse en el proximo minuto";
                Equivalencia2.FontSize = 12;
              } else {
                MessageBox.Show("la cantidad de segundos debe ser un numero positivo");
            }
            
        }
    }
}
