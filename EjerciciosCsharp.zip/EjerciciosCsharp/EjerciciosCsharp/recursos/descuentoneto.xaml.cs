﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para descuentoneto.xaml
    /// </summary>
    public partial class descuentoneto : Window
    {
        public descuentoneto()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double sueldo, sueldoneto, descuento;

            sueldo = double.Parse(sueldotxt.Text);
            if (sueldo <= 1000 && sueldo >= 0) {
                descuento = sueldo * 0.1;
                sueldoneto = sueldo - descuento;
                desc.Text = "" + descuento;
                neto.Text = "" + sueldoneto;
            } else if (sueldo <= 2000 && sueldo >= 0) {
                descuento = (sueldo - 1000) * 0.05 + (1000 * 0.1);
                sueldoneto = sueldo - descuento;
                desc.Text = "" + descuento;
                neto.Text = "" + sueldoneto;
            } else if (sueldo > 2000) {
                descuento = (sueldo - 2000) * 0.03 + (1000 * 0.05) + (1000 * 0.10);
                sueldoneto = sueldo - descuento;
                desc.Text = "" + descuento;
                neto.Text = "" + sueldoneto;
            } else {
                MessageBox.Show("error el sueldo no puede ser negativo");
                
            }
        
        }
    }
}
