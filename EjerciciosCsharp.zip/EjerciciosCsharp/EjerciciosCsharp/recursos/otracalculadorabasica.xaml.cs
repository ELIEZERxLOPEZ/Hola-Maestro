﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para otracalculadorabasica.xaml
    /// </summary>
    public partial class otracalculadorabasica : Window
    {
        public otracalculadorabasica()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {

            double num1, num2, c, suma, resta, multiplicacion, division;
            c = 0;

            c = c + 1;

            num1 = double.Parse(val1.Text);
            if (num1 != 0) {

                num2 = double.Parse(val2.Text);
            suma = num1 + num2;
            resta = num1 - num2;
            multiplicacion = num1 * num2;
            division = Math.Round(num1 / num2, 2);


            sumatxt.Text = $"{suma}";
            restatxt.Text = $"{resta}";
            Multitxt.Text = $"{multiplicacion}";
            divstxt.Text = $"{division}";


            } else {
                for(var i = 0; i < 4; i++) {
                    MessageBox.Show("Crash!");
                }
                MessageBox.Show("Cerrar ventana!");
                this.Close();
            }
        }
    }
}

