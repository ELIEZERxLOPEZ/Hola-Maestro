﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para MontoYdescuento.xaml
    /// </summary>
    public partial class MontoYdescuento : Window
    {
        public MontoYdescuento()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            double monto, descuento;
            Console.WriteLine("ingrese monto");
            monto = double.Parse(MontoTXT.Text);
            if (monto > 100) {
                descuento = monto * 0.1;
                double total = monto - descuento;
                montoRegist.Text = "RD$ " + monto;
                desc.Text = "RD$ " + descuento;
                Totaltxt.Text = "RD$ " + total;
                
            } else if (monto <= 100 && monto > 0) {
                descuento = monto * 0.2;
                double total = monto - descuento;
                montoRegist.Text = "RD$ " + monto;
                desc.Text = "RD$ " + descuento;
                Totaltxt.Text = "RD$ " + total;
            } else {
               MessageBox.Show("error el monto no puede ser negativo");
            }
            
        }
    }
}
