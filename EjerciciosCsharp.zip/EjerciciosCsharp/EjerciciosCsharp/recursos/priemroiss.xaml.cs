﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para priemroiss.xaml
    /// </summary>
    public partial class priemroiss : Window
    {
        public priemroiss()
        {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            int numero, suma, x;
            suma = 0;
           
            numero = int.Parse(nusmero.Text);
            if (numero < 8) {

                Equivalencia1.Text = "Error el numero ingresado es menor a 8";
            } else {
                for (x = 8; x <= numero; x = x + 1) {
                    suma = suma + x;
                }
               
               Equivalencia1.Text = $"La suma de la serie de rango 8 hasta{numero}, con un incremento de 1 es: {suma} ";
   }
        }
    }
}
