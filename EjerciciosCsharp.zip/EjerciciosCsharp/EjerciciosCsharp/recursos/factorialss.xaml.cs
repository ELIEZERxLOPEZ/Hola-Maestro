﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EjerciciosCsharp.recursos
{
    /// <summary>
    /// Lógica de interacción para factorialss.xaml
    /// </summary>
    public partial class factorialss : Window {
        public factorialss() {
            InitializeComponent();
        }

        private void nonegative(object sender, TextCompositionEventArgs e) {
            e.Handled = !int.TryParse(e.Text, out _);
        }

        private void Calcbtn_Click(object sender, RoutedEventArgs e) {
            int numero, factorial, i;
           
            numero = int.Parse(nusmero.Text);
            factorial = 1;
            for (i = 1; i <= numero; i++) {
                factorial = factorial * i; //factorial *= i
            }



            Equivalencia1.Text = $"{numero}! =  {factorial}";

        }
    }
}
