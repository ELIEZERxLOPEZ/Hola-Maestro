﻿// File: EjerciciosCsharp/MainWindow.xaml.cs
using System.Windows;
using EjerciciosCsharp.recursos;

namespace EjerciciosCsharp {
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
        }

        private void HorasTrabajoClick(object sender, RoutedEventArgs e) {
            HorasTrabajadas horas = new HorasTrabajadas();
            horas.Show();
        }

        private void descuentonetoClick(object sender, RoutedEventArgs e) {
            HorasTrabajadas horas = new HorasTrabajadas();
            horas.Show();
        }

        private void descuentoneto_Click(object sender, RoutedEventArgs e) {
            descuentoneto descuento = new descuentoneto();
            descuento.Show();
        }

        private void MontYdesc_Click(object sender, RoutedEventArgs e) {
            MontoYdescuento montoYdescuento = new MontoYdescuento();
            montoYdescuento.Show();
        }

        private void SegundosMinutos_Click(object sender, RoutedEventArgs e) {
            SegundosMinutos segundosMinutos = new SegundosMinutos();
            segundosMinutos.Show();
        }

        private void minutosadias_Click(object sender, RoutedEventArgs e) {
            MinutosAdias minutosAdias = new MinutosAdias();
            minutosAdias.Show();
        }

        private void NumNat_Click(object sender, RoutedEventArgs e) {
            NumerosNat nm = new NumerosNat();
            nm.Show();
        }

        private void SumaSalariosTrabj_Click(object sender, RoutedEventArgs e) {
            sumadetrabj sm = new sumadetrabj();
            sm.Show();
        }

        private void TarifaYhoras_Click(object sender, RoutedEventArgs e) {
            TarifayHoras tr = new TarifayHoras();
            tr.Show();
        }

        private void NotasEst_Click(object sender, RoutedEventArgs e) {
            NotasEstudiantes nt = new NotasEstudiantes();
            nt.Show();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e) {
            Sumadedigitos sm = new Sumadedigitos();
            sm.Show();
        }



        private void MenuItem_Click_1(object sender, RoutedEventArgs e) {
           
        }

        private void facturasEmition_Click(object sender, RoutedEventArgs e) {
            EmisionFactura em = new EmisionFactura();
            em.Show();
        }

       

        private void parimpars_Click(object sender, RoutedEventArgs e) {
            parimpar parimpar = new parimpar();
            parimpar.Show();
        }

        private void factr_Click(object sender, RoutedEventArgs e) {
            factorialss factorialss = new factorialss();
            factorialss.Show();
        }

        private void mdia_Click(object sender, RoutedEventArgs e) {
            Media media = new Media();
            media.Show();
        }

        private void sumprod_Click(object sender, RoutedEventArgs e) {
            sumadeproducto sm = new sumadeproducto();
            sm.Show();
        }

        private void lexorvocal_Click(object sender, RoutedEventArgs e) {
            Lectorvocal lectorvocal = new Lectorvocal();
            lectorvocal.Show();
        }

        private void fraccion_Click(object sender, RoutedEventArgs e) {
            ParteFraccion parte = new ParteFraccion();
            parte.Show();
        }

        private void Cuadract_Click(object sender, RoutedEventArgs e) {
            ecuacionCuadratt s = new ecuacionCuadratt();
            s.Show();
        }

       

        private void operacionesBasicsss_Click(object sender, RoutedEventArgs e) {
            calculadoraBasica f = new calculadoraBasica();
            f.Show();
        }

        private void cuadradocc_Click(object sender, RoutedEventArgs e) {
            RaizcuadradaCubica r = new RaizcuadradaCubica();
            r.Show();
        }

        private void sicero_Click(object sender, RoutedEventArgs e) {
            otracalculadorabasica otr = new otracalculadorabasica();
            otr.Show();
        }

       
        private void hipotenusa_Click(object sender, RoutedEventArgs e) {
            Hipotenusass hp = new Hipotenusass();
            hp.Show();
        }

        

        private void areatrinng_Click(object sender, RoutedEventArgs e) {
            areatriangulo fd = new areatriangulo();
            fd.Show();
        }

        private void longit_Click(object sender, RoutedEventArgs e) {
            longitudCrircunferencia f = new longitudCrircunferencia();
            f.Show();
        }

        private void resst_Click(object sender, RoutedEventArgs e) {
            restaurtante f = new restaurtante();
            f.Show();
        }

        private void enesemos_Click(object sender, RoutedEventArgs e) {
            priemroiss priemroiss = new priemroiss();
            priemroiss.Show();
        }

        private void egresss_Click(object sender, RoutedEventArgs e) {
            egresosEmprsss f = new egresosEmprsss();
            f.Show();
        }

        private void nott_Click(object sender, RoutedEventArgs e) {
            notasdefit f = new notasdefit();
            f.Show();
        }
    }
}